#ifndef CONVEXHULL_H
#define CONVEXHULL_H

#include <bits/stdc++.h>
#include "fundamentals.h"

using namespace std;

//!This class contains various convex hull implementations
class convex_hull
{
    public:
    //! This function calculates the convex hull of a given set of points, based on Graham Scan Algorithm.
    /*!
    	\param pts A vector of points whose convex hull is to be found.
    	\return A vector of points representing the convex hull in anti-clockwise order.
    */
    vector<point> graham_scan(const vector<point>&);

    //! This function calculates the convex hull of a given set of points, based on Jarvis March Algorithm.
    /*!
        \param points a vector of points whose convex hull is to be found.
    	\return A vector of points representing the convex hull in anti-clockwise order.
    */
    vector<point> jarvis_march(const vector<point>&);

    //! This function calculates the upper bridge of a given set of points,
    //! across a vertical line, based on Kirkpatrick Seidel Algorithm.
    //!	Since this function is for internal use, the user should use with care.
    /*!
        \param points a vector of points whose upper bridge is to be found.
        \param a The vertical line across which bridge is to be found is x = a.
    	\return A pair of points representing the upper bridge.
    */
	private:
    pair<point, point> upper_bridge(const vector<point>&, long double);

    //! This function calculates the upper hull of a given set of points,
    //! based on Kirkpatrick Seidel Algorithm.
    //!	Since this function is for internal use, the user should use with care.
    /*!
        \param points a vector of points whose upper hull is to be found.
        \param pmin left extreme point.
        \param pmax right extreme point.
    	\return A vector of points representing the upper hull from left to right.
    */
    vector<point> upper_hull(const vector<point>&, point , point);

    //!This function calculates the convex hull of a given set of points, based on Kirkpatrick Seidel Algorithm.
    /*!
        \param points - a vector of points whose convex hull is to be found.
        \return A vector of points representing the convex hull in anti-clockwise order.
    */
	public:
    vector<point> kirkpatrick_seidel(const vector<point>&);
};

#include "convex_hull.cpp"

#endif
