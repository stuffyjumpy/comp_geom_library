#ifndef POLYTRIANGLE_H
#define POLYTRIANGLE_H

#include <bits/stdc++.h>
#include "fundamentals.h"
#include "dcel.h"

using namespace std;

//! A class which performs polygon triangulation.
class polygon_triangulation
{
	private:
	/*! 
	Removes merge and split vertices by adding diagonals
		\param d dcel containing the polygon
	*/
	void make_monotone(dcel&);
	/*! 
	Triangulates the entire polygon
		\param d dcel containing the y monotone pieces of the polygon
	*/
	void triangulate_monotone_pieces(dcel&);

	public:
	/*! 
	Calls necessary functions to triangulate the polygon
		\param v vector containing all points of the polygon in counter clockwise direction
		\return DCEL containing the triangulated polygon
	*/
	dcel triangulate_polygon(const vector<point>&);
	/*!
	Comparator struct for status data structure containing segments.
	*/
	struct status_comparator
	{
		/*!
		Comparison function for two items of the set.
		*/
		bool operator()(pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int> > a,
						pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int> > b) const;
	};
};


#include "polygon_triangulation.cpp"

#endif
