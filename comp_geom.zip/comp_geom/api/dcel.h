#ifndef DCEL_H
#define DCEL_H

#include <bits/stdc++.h>
#include "fundamentals.h"

using namespace std;

//! Class to build a doubly connected edge list
class dcel
{
	//! Represents a vertex of the polygon
	struct vertex
	{
		//! Represents a point in the coordinate system
		point p;
		//! tag represents point number and e
		int tag, e;
	};

	//! Represents an edge of the polygon
	struct edge
	{
		int origin, twin, nxt, prv, f;
	};

	//! Represents a face of the polygon.
	struct face
	{
		int e;
	};

	//! vertices stores a vector of objects of type vertex
	vector<vertex> vertices;
	//! edges stores a vector of objects of type edge
	vector<edge> edges;
	//! faces stores a vector of objects of type face
	vector<face> faces;

	public:

	//! n stores the number of vertices of the polygon
	int n;
	//! Constructor to initialize a dcel
    /*!
        \param v a vector of points
    */
	dcel(const vector<point>&);
	//! Adds a diagonal to the polygon
    /*!
        \param tag tag-number of a point of an edge
		\param tag tag-number of a point of an edge
    */
	void add_edge(int, int);
	//!  Calculates and returns all faces of the dcel except the external unbounded faces
	vector< vector<pair<int, point> > > get_proper_faces();
	//! Returns a vector of pair of tag and point of the polygon
	vector< pair<int, point> > get_points();
	//! Returns a vector of all the edges of the polygon
	vector< pair<point, point> > get_polygon_edges();
	//! Returns a vector of all the diagonals of the polygon
	vector< pair<point, point> > get_diagonal_edges();
};

#include "dcel.cpp"

#endif
