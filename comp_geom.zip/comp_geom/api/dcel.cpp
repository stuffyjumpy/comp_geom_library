#include "dcel.h"

dcel::dcel(const vector<point>& polygon)
{
	/*
    Constructor to initialize a dcel.

    Parameters:
    polygon - vector of points of the polygon */

	n = polygon.size();
	if(polygon.size() < 3) return;
	for(int i = 0; i < n; i++)
	{
		vertex v;
		v.p.set_point(polygon[i].get_point_cartesian().first,
					polygon[i].get_point_cartesian().second);
		v.e = (2*i + 2*n - 1) % (2*n);
		v.tag = i;
		vertices.push_back(v);
	}
	for(int i = 0; i < 2*n; i+=2)
	{
		edge e1, e2;
		e1.origin = (i/2) % (n);
		e2.origin = (i/2 + 1) % (n);
		e1.twin = i + 1;
		e2.twin = i;
		e1.nxt = (i+2) % (2*n);
		e2.nxt = (i-1+(2*n)) % (2*n);
		e2.prv = (i+3) % (2*n);
		e1.prv = (i-2+(2*n)) % (2*n);
		e1.f = 1;
		e2.f = 0;
		edges.push_back(e1);
		edges.push_back(e2);
	}
	face f;
	f.e = 1;
	faces.push_back(f);
	f.e = 0;
	faces.push_back(f);
}

void dcel::add_edge(int p, int q)
{
	/*
    Adds an edge to the dcel

    Parameters:
    p - tag value of a point of an edge
	q - tag value of a point of an edge */
	edge e1, e2;
	if(p < q) swap(p, q);
	int outp = edges[edges[vertices[p].e].twin].nxt, outq;
	while(edges[outp].f != 0)
	{
		outq = edges[edges[vertices[q].e].twin].nxt;
		while(edges[outq].f != 0)
		{
			if(edges[outp].f == edges[outq].f)
				break;
			outq = edges[edges[outq].twin].nxt;
		}
		if(edges[outp].f == edges[outq].f and edges[outq].f != 0)
			break;
		outp = edges[edges[outp].twin].nxt;
	}
	if(!(edges[outp].f == edges[outq].f and edges[outq].f != 0)) return;
	e1.origin = q;
	e2.origin = p;
	e1.twin = edges.size() + 1;
	e2.twin = edges.size();
	e1.nxt = outp;
	e2.nxt = outq;
	e2.prv = edges[outp].prv;
	e1.prv = edges[outq].prv;
	e1.f = edges[outp].f;
	faces[e1.f].e = edges.size();
	e2.f = faces.size();

	face f;
	f.e = edges.size() + 1;
	faces.push_back(f);
	edges[edges[outp].prv].nxt = edges.size() + 1;
	edges[edges[outq].prv].nxt = edges.size();
	edges[outp].prv = edges.size();
	edges[outq].prv = edges.size() + 1;
	edges.push_back(e1);
	edges.push_back(e2);
	outp = outq;
	do
	{
		edges[outq].f = faces.size() - 1;
		outq = edges[outq].nxt;
	}while(outq != outp);
}

vector< vector<pair<int, point> > > dcel::get_proper_faces()
{
	/*
    Calculates and returns all faces of the dcel except the external unbounded faces
	*/
    vector< vector<pair<int, point> > > ret;
	vector<pair<int, point> > tmp;
	for(int i = 1; i < faces.size(); i++)
	{
		face f = faces[i];
		tmp.clear();
		int e = f.e;
		tmp.push_back(make_pair(vertices[edges[e].origin].tag,
								vertices[edges[e].origin].p));
		while(tmp.size() < 2 or tmp[0] != tmp[tmp.size()-1])
		{
			e = edges[e].nxt;
			tmp.push_back(make_pair(vertices[edges[e].origin].tag,
									vertices[edges[e].origin].p));
		}
		tmp.pop_back();
		ret.push_back(tmp);
	}
	return ret;
}

vector< pair<int, point> > dcel::get_points()
{
	/*
    Returns a vector of pair of tag and point of the polygon
	*/
	vector< pair<int, point> > ret;
	for(vertex v: vertices)
	{
		ret.push_back(make_pair(v.tag, v.p));
	}
	return ret;
}

vector< pair<point, point> > dcel::get_polygon_edges()
{
	//! Returns a vector of pair of points of an edge of the polygon
	vector< pair<point, point> > ret;
	for(int i = 0; i < 2*n; i+=2)
		ret.push_back(make_pair(vertices[edges[i].origin].p, vertices[edges[i+1].origin].p));
	return ret;
}

vector< pair<point, point> > dcel::get_diagonal_edges()
{
	//! Returns a vector of pair of points of a diagonal of the polygon
	vector< pair<point, point> > ret;
	for(int i = 2*n; i < edges.size(); i+=2)
		ret.push_back(make_pair(vertices[edges[i].origin].p, vertices[edges[i+1].origin].p));
	return ret;
}
