#ifndef FUNDAMENTALS_H
#define FUNDAMENTALS_H

#include <bits/stdc++.h>

using namespace std;

const long double eps = 1e-17;
const long double MAXVAL = 1e308;
const int MAXINT = 1e9;

//!  This function evaluates the value of pi at compile time.
/*!
    \return The (approximated) decimal value of pi.
*/
constexpr long double pi();

//! Represents an angle.
class angle
{
    private:
    //! value stores value of angle in radians or degrees depending on usage.
    long double value;
    //! x stores adjacent side of triangle with this angle
    long double x;
    //! y stores opposite side of triangle with this angle
    long double y;
    //! quad stores quadrant of angle.
    int quad;
    public:

    //! Constructor to initialize an angle instance.
    /*!
        \param rad the value of the angle in radians. 
    */
    angle(long double);

    //! Constructor to initialize an angle instance, where the angle is represented by an opposite and adjecent ratio.
    /*!
        \param y length of opposite edge of the angle.
        \param x length of adjecent edge of the angle. 
    */
    angle(long double, long double);

    //! Sets the value of an angle instance. 
    /*!
        \param rad the value of the angle in radians. 
    */
    void set_angle(long double);

    //! Sets the value of an angle instance, where the angle is represented by an opposite and adjecent ratio.

    /*!
        \param y length of opposite edge of the angle.
        \param x length of adjecent edge of the angle. 
    */
    void set_angle(long double, long double);


    //! Returns the value of the angle in radians or degrees.
    /*!
        \param type the angle is in degrees if this parameter is false, else in radian.
        \return The value in the desired units.
    */
    long double get_value(bool) const;

    //! Returns the value of the angle as an opposite and ajecent ratio.
    /*!
        \return A pair representing the opposite and adjecent lengths respectively.
    */
    pair< long double, long double > get_ratio() const;

    //! Returns the quadrant of the angle.
    /*!
        \return 1, 2, 3 or 4, based on the quadrant.
    */
    int get_quadrant() const;

    //! Returns the tangent of the angle.
    /*!
        \return The tangent of the angle.
    */
    long double get_tan() const;
};

    
    //! Less than comparison of angles.
    /*!
        \param a 1st angle.
        \param b second angle.
        \return boolean true is a < b, else boolean false.
    */
bool operator<(const angle&, const angle&);

    
    //!Greater than comparison of angles.
    /*!
        \param a 1st angle.
        \param b second angle.
        \return boolean true is a > b, else boolean false.
    */
bool operator>(const angle&, const angle&);

    //!Equal to comparison of angles.
    /*!
        \param a 1st angle.
        \param b second angle.
        \return boolean true is a == b, else boolean false.
    */
bool operator==(const angle&, const angle&);

    
    //! Not Equal to comparison of angles.
    /*!
        \param a 1st angle.
        \param b second angle.
        \return boolean true is a != b, else boolean false.
    */
bool operator!=(const angle&, const angle&);

//!Represents a point.
class point
{
    //! x  x-coordinate of a point
    long double x;
    //! y y-coordinate of a point
    long double y;
    //! r_sq squared radius of a point.
    long double r_sq;
    //! theta angle of a point.
    angle theta;
    public:

    //! Constructor of an instance of point.
    /*!
        \param x x-coordinate of point
        \param y y-coordinate of point
        \param ox x-coordinate of origin
        \param oy x-coordinate of origin
    */
    point(long double, long double, long double, long double);

    //! Constructor of an instance of point in polar form.
    /*!
        \param r radius of point
        \param theta angle of point
    */
    point(long double, angle);

    //!Sets the value of a point.
    /*!
        \param x x-coordinate of point
        \param y y-coordinate of point
        \param ox x-coordinate of origin
        \param oy x-coordinate of origin
    */
    void set_point(long double, long double, long double, long double);

    //! Sets the value of a point using polar coordinates.
    /*!
        \param r radius of point
        \param theta angle of point
    */
    void set_point(long double, angle);

    //! Returns the Cartesian coordinates of the point.
    /*!
        \return pair of the form (x coordinate, y coordinate).
    */
    pair< long double, long double>  get_point_cartesian() const;

    //!Returns the polar coordinates of the point.
    /*!
        \return pair of the form (radius of point, angle of point).
    */
    pair< long double, angle>  get_point_polar() const;

    //! Returns the original cartesian coordinates of the point, whose origin is shifted.
    /*!
        \param p the origin
        \return pair of the form (x coordinate, y coordinate).
    */
    pair< long double, long double>  get_point_unnormalized(point) const;

    //! Returns squared radius of the point.
    /*!
        \return Squared radius of the point.
    */
    long double get_radius_squared() const;
};

    //! less than comparison of points based on cartesian coordinates.
    /*!
        \param a 1st point.
        \param b second point.
        \return boolean true is a < b, else boolean false.
    */
bool less_than_cartesian(const point&, const point&);

    //! less than comparison of points based on polar coordinates.
    /*!
        \param a 1st point.
        \param b second point.
        \param boolean true is a < b, else boolean false.
    */
bool less_than_polar(const point&, const point&);

    //!Equal to comparison of points.
    /*!
        \param a 1st point.
        \param b second point.
        \param boolean true is a == b, else boolean false.
    */
bool operator==(const point&, const point&);

    //!Not Equal to comparison of points.
    /*!
        \param a 1st point.
        \param b second point.
        \return boolean true is a != b, else boolean false.
    */
bool operator!=(const point&, const point&);

    //! Swap two points.
    /*!
        \param a 1st point.
        \param b second point.
    */
void swap(point&, point&);

template <class RandomAccessIterator>

    //! Sorts a container of points.
    /*!
        \param f iterator to 1st point.
        \param l iterator to last point.
        \param pol performs polar sort if true else cartesian sort..
    */
void sort_points(RandomAccessIterator, RandomAccessIterator, bool pol = false);


    //! Returns 2*(signed area of triangle).
    /*!
        \param a 1st vertex
        \param b 2nd vertex
        \param c 3rd vertex
        \return returns 2*(signed area of triangle)
    */
long double twice_triangle_signed_area(point a, point b, point c);

#include "fundamentals.cpp"

#endif
