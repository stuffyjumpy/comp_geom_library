#include "polygon_triangulation.h"

bool polygon_triangulation::status_comparator::operator()(
			pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int> > a,
			pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int> > b) const
{
	/*!
	Compares two instances in the status.
	*/
	point A(a.first.first.first, a.first.first.second);
	point B(a.first.second.first, a.first.second.second);
	point C(b.first.first.first, b.first.first.second);
	point D(b.first.second.first, b.first.second.second);
	if(C == D)
	{
		if(twice_triangle_signed_area(A, B, C) > 0) return true;
		if(fabs(twice_triangle_signed_area(A, B, C)) < eps) return true;
		return false;
	}
	if(A == B)
	{
		if(twice_triangle_signed_area(C, D, B) < 0) return true;
		if(fabs(twice_triangle_signed_area(C, D, B)) < eps) return true;
		return false;
	}
	if(twice_triangle_signed_area(C, D, A) > 0.0 and twice_triangle_signed_area(C, D, B) > 0.0) return false;
	if(twice_triangle_signed_area(A, B, C) < 0.0 and twice_triangle_signed_area(A, B, D) < 0.0) return false;
	return true;
}

dcel polygon_triangulation::triangulate_polygon(const vector<point>& pts)
{
	/*!
    This function calls the make_monotone method to remove split and merge vertices
	and calls triangulate_monotone_pieces to triangulate the polygon

    Parameters:
    pts - a vector of points of the polygon.

    Return Value:
    Instance of class dcel*/
	dcel d(pts);
    if(pts.size() < 4) return d;
	make_monotone(d);
	triangulate_monotone_pieces(d);
	return d;
}

void polygon_triangulation::make_monotone(dcel& obj)
{
	/*!
    This function removes split and merge vertices of the polygon by adding diagonals

    Parameters:
    obj - Instance of class dcel
    */
	vector<pair<int,point>> Vertices = obj.get_points();

    vector<pair<pair<long double,long double>,pair<int,int>>> Points;
    for(auto p:Vertices){
        pair<long double,long double> temp = p.second.get_point_cartesian();
        Points.push_back(make_pair(temp,make_pair(p.first,0)));
    }

    vector<int> type(obj.n, 0);

    for(int i=0;i<Points.size(); i++){
        pair<long double,long double> a = Points[(i-1+Points.size())%Points.size()].first;
        pair<long double,long double> b = Points[(i+Points.size())%Points.size()].first;
        pair<long double,long double> c = Points[(i+1+Points.size())%Points.size()].first;
        bool chk1 = ((b.second<a.second) or (fabs(b.second-a.second) < eps and a.first < b.first));
        bool chk2 = ((b.second<c.second) or (fabs(b.second-c.second) < eps and c.first < b.first));
        if(chk1 && chk2){
            long double val = twice_triangle_signed_area(point(a.first, a.second), point(b.first, b.second), point(c.first, c.second));
            if(val > 0)
            {
                Points[(i+Points.size())%Points.size()].second.second =2;   // end vertex
                type[Points[(i+Points.size())%Points.size()].second.first] = 2;
            }
            else
            {
                Points[(i+Points.size())%Points.size()].second.second = 4;     //merge vertex
                type[Points[(i+Points.size())%Points.size()].second.first] = 4;
            }
            continue;
        }
        chk1 = ((b.second>a.second) or (fabs(b.second-a.second) < eps and a.first > b.first));
        chk2 = ((b.second>c.second) or (fabs(b.second-c.second) < eps and c.first > b.first));
        if(chk1 && chk2)  {
            long double val = twice_triangle_signed_area(point(a.first, a.second), point(b.first, b.second), point(c.first, c.second));
            if(val > 0)
            {
                Points[(i+Points.size())%Points.size()].second.second = 1;   // start vertex
                type[Points[(i+Points.size())%Points.size()].second.first] = 1;
            }
            else {
                Points[(i+Points.size())%Points.size()].second.second = 3;     // split vertex
                 type[Points[(i+Points.size())%Points.size()].second.first] = 3;
            }
            continue;
        }
    }

    for(int i=0;i<Points.size(); i++){
    	long double temp = Points[i].first.first;
        Points[i].first.first = -1*Points[i].first.second;
        Points[i].first.second = temp;
    }

    sort(Points.begin(),Points.end());

    for(int i=0;i<Points.size(); i++){
        long double temp = Points[i].first.second;
        Points[i].first.second = -1*Points[i].first.first;
        Points[i].first.first = temp;
    }
    point top_pt;
    top_pt.set_point(Points[0].first.first,Points[0].first.second);

    vector<int> side(obj.n, 0);
    int cnt = 0, cur = Points[0].second.first, idx = 0;

    while(Vertices[idx].first != Points[0].second.first) idx++;
    do
    {
        if(type[Vertices[idx].first] != 0) cnt++;
        else if(cnt%2) side[Vertices[idx].first] = 1;
        idx = (idx + 1 + obj.n)%(obj.n);
    }while(Vertices[idx].first != Points[0].second.first);

    point bot_pt;
    bot_pt.set_point(Points[Points.size()-1].first.first,Points[Points.size()-1].first.second);

    vector<pair<long double,long double>> tag_to_point(Points.size(),make_pair(0,0));
    for(int i=0;i<Points.size();i++)
        tag_to_point[Points[i].second.first] = Points[i].first;

    int sz = Points.size();
    set<pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>>, status_comparator> status;
    for(int i=0;i<Points.size();i++)
   	{
    	if(Points[i].second.second==1){
            pair<long double,long double> v1 = tag_to_point[Points[i].second.first];
            pair<long double,long double> v2 = tag_to_point[(Points[i].second.first+1+sz)%sz];
            status.insert(make_pair(make_pair(v1,v2),make_pair(Points[i].second.first,Points[i].second.second)));
        }
        if(Points[i].second.second == 2){
            int tag = (Points[i].second.first-1+sz)%sz;
            pair<long double,long double> v1 = tag_to_point[tag];
            set<pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>>>:: iterator it;

            pair<long double,long double> v2 = Points[i].first;
            it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT, MAXINT)));
             --it;
            if((*it).second.second == 4){
                obj.add_edge((*it).second.first,Points[i].second.first);
            }
            status.erase(it);
        }

        if(Points[i].second.second == 3){
            pair<long double,long double> v1 = Points[i].first;
            pair<long double,long double> v2 = Points[i].first;
            set<pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>>>:: iterator it;
            it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT,MAXINT)));
             --it;

            obj.add_edge((*it).second.first,Points[i].second.first);

            pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>> temp = *it;
            status.erase(it);
            temp.second = Points[i].second;
            status.insert(temp);

            v1 = tag_to_point[Points[i].second.first];
            v2 = tag_to_point[(Points[i].second.first+1+sz)%sz];
            status.insert(make_pair(make_pair(v1,v2),make_pair(Points[i].second.first,Points[i].second.second)));
        }

        if(Points[i].second.second == 4){
            int tag = (Points[i].second.first-1+sz)%sz;
            pair<long double,long double> v1 = tag_to_point[tag];
            set<pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>>>:: iterator it;

            pair<long double,long double> v2 = Points[i].first;
            it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT,MAXINT)));
             --it;

            if((*it).second.second == 4){
                obj.add_edge((*it).second.first,Points[i].second.first);
            }
            status.erase(it);
            v1 = Points[i].first;
            v2 = Points[i].first;
            it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT,MAXINT)));
             --it;
            if((*it).second.second==4){
                obj.add_edge((*it).second.first,Points[i].second.first);
            }
            pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>> temp = *it;
            
            status.erase(it);
            temp.second = Points[i].second;
            status.insert(temp);
        }

        if(Points[i].second.second==0){
            point cur_pt;
            cur_pt.set_point(Points[i].first.first,Points[i].first.second);
            if(side[Points[i].second.first] == 1){
                int tag = (Points[i].second.first-1+sz)%sz;
                pair<long double,long double> v1 = tag_to_point[tag];
                set<pair<pair<pair<long double,long double>,pair<long double,long double> >,pair<int,int>>>:: iterator it;

                pair<long double,long double> v2 = Points[i].first;
                it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT,MAXINT)));
                 --it; 
                if((*it).second.second == 4){
                    obj.add_edge((*it).second.first,Points[i].second.first);
                }
                status.erase(it);
                v1 = tag_to_point[Points[i].second.first];
                v2 = tag_to_point[(Points[i].second.first+1+sz)%sz];

                status.insert(make_pair(make_pair(v1,v2),make_pair(Points[i].second.first,Points[i].second.second)));
            }
            else{
                auto v1 = Points[i].first;
                auto v2 = Points[i].first;
                auto it = status.lower_bound(make_pair(make_pair(v1,v2),make_pair(MAXINT,MAXINT)));
                --it;
                if((*it).second.second==4){
                    obj.add_edge((*it).second.first,Points[i].second.first);
                }
                pair<pair<pair<long double,long double>,pair<long double,long double>>,pair<int,int>> temp = *it;
                status.erase(it);
                temp.second = Points[i].second;
                status.insert(temp);
            }
        }
    }
}

void polygon_triangulation::triangulate_monotone_pieces(dcel& d)
{
	/*!
    This function triangulates the polygon by adding diagonals

    Parameters:
    obj - Instance of class dcel
	*/
	vector<int> chain(d.n, 0);
	auto poly = d.get_proper_faces();
	queue<int> changed;
	for(auto pol: poly)
	{
		if(pol.size() <= 3)
			continue;
		vector< pair< pair<long double, long double>, int> > tmp;
		for(auto p: pol)
			tmp.push_back(make_pair(make_pair(-1*p.second.get_point_cartesian().second,
												p.second.get_point_cartesian().first),
									p.first));
		sort(tmp.begin(), tmp.end());
		int tp = tmp[0].second, bm = tmp[tmp.size()-1].second;
		int idx = 0;
		while(!changed.empty())
		{
			chain[changed.front()] = 0;
			changed.pop();
		}
		while(pol[idx].first != tp) idx++;
		while(pol[idx].first != bm)
		{
			chain[pol[idx].first] = 1;
			changed.push(pol[idx].first);
			idx = (idx+1)%(pol.size());
		}
		for(auto& p: tmp)
		{
			swap(p.first.first, p.first.second);
			p.first.second = -1 * p.first.second;
		}
		stack< pair< pair<long double, long double>, int> > s;
		s.push(tmp[0]);
		s.push(tmp[1]);
		for(int j = 2; j < tmp.size() - 1; j++)
		{
			long double v1 = chain[tmp[j].second];
			long double v2 = chain[s.top().second];
			if(v1 != v2)
			{
				auto tp = s.top();
				do
				{
					d.add_edge(tmp[j].second, s.top().second);
					s.pop();
				}while(s.size() > 1);
				s.pop();
				s.push(tp);
				s.push(tmp[j]);
			}
			else
			{
				auto prv = s.top();
				s.pop();
				auto ar = twice_triangle_signed_area(point(tmp[j].first.first, tmp[j].first.second),
														point(prv.first.first, prv.first.second),
												point(s.top().first.first, s.top().first.second));

				while((ar < 0 and v1 == 1) or (ar > 0 and v1 == 0))
				{
					d.add_edge(tmp[j].second, s.top().second);
					prv = s.top();
					s.pop();
					if(s.empty()) break;
					ar = twice_triangle_signed_area(point(tmp[j].first.first, tmp[j].first.second),
														point(prv.first.first, prv.first.second),
												point(s.top().first.first, s.top().first.second));
				}
				s.push(prv);
				s.push(tmp[j]);
			}
		}
		s.pop();
		while(s.size() > 1)
		{
			d.add_edge(tmp[tmp.size()-1].second, s.top().second);
			s.pop();
		}
	}
	return;
}
