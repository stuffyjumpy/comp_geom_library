var searchData=
[
  ['operator_28_29',['operator()',['../structpolygon__triangulation_1_1status__comparator.html#acb6902bb456a8e9040d52bbe69e4c215',1,'polygon_triangulation::status_comparator']]]
];
