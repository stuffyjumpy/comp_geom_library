var searchData=
[
  ['jarvis_5fmarch',['jarvis_march',['../classconvex__hull.html#aa1387716f64faeb45aff2f2c47596b05',1,'convex_hull']]]
];
