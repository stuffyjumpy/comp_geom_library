var searchData=
[
  ['point',['point',['../classpoint.html#af6ae7b1529ec7bd4ee4129ce2e4f9775',1,'point::point(long double, long double, long double, long double)'],['../classpoint.html#a2b071df8844629d4bfe7a4702260a9f9',1,'point::point(long double, angle)']]]
];
