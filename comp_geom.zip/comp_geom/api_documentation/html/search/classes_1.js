var searchData=
[
  ['convex_5fhull',['convex_hull',['../classconvex__hull.html',1,'']]]
];
