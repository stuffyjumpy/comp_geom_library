var searchData=
[
  ['get_5fdiagonal_5fedges',['get_diagonal_edges',['../classdcel.html#ac29948584418b15b5ec2d34edb31264d',1,'dcel']]],
  ['get_5fpoint_5fcartesian',['get_point_cartesian',['../classpoint.html#a177d9b5e7bcadfcbe43117ea5f8f5efb',1,'point']]],
  ['get_5fpoint_5fpolar',['get_point_polar',['../classpoint.html#abb0e764395c87ace50d3db576cf0ea61',1,'point']]],
  ['get_5fpoint_5funnormalized',['get_point_unnormalized',['../classpoint.html#ae074e0c127b57f7255e78942b3e72aeb',1,'point']]],
  ['get_5fpoints',['get_points',['../classdcel.html#a5d6df41372b1fdae32ee8c68df25d3d5',1,'dcel']]],
  ['get_5fpolygon_5fedges',['get_polygon_edges',['../classdcel.html#af3cb893598b6d6fa48ca673a8dcce70c',1,'dcel']]],
  ['get_5fproper_5ffaces',['get_proper_faces',['../classdcel.html#a64cbeb84a0617d7afe43ad8fef3e1583',1,'dcel']]],
  ['get_5fquadrant',['get_quadrant',['../classangle.html#add527bd5ed67b6ad993bc0c74cf28e71',1,'angle']]],
  ['get_5fradius_5fsquared',['get_radius_squared',['../classpoint.html#ad75fb52af06efebe7354deae3d7d8779',1,'point']]],
  ['get_5fratio',['get_ratio',['../classangle.html#a3a464ba59e72c2101554ddb4c545bb7f',1,'angle']]],
  ['get_5ftan',['get_tan',['../classangle.html#abc5c0a478345198a0afdbaf0f3affe0b',1,'angle']]],
  ['get_5fvalue',['get_value',['../classangle.html#a36180714b7eef2d01bad0ca127f59fc5',1,'angle']]],
  ['graham_5fscan',['graham_scan',['../classconvex__hull.html#a6c65952e8deae37ec0286a1c9e388fff',1,'convex_hull']]]
];
