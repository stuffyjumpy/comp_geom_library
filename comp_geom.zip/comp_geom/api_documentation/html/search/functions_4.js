var searchData=
[
  ['kirkpatrick_5fseidel',['kirkpatrick_seidel',['../classconvex__hull.html#ab869c754c213859b350c8c2a4bac64c3',1,'convex_hull']]]
];
